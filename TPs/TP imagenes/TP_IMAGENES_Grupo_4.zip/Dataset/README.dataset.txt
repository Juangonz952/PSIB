# TEZ_ROI_AUG > 2023-04-28 8:15pm
https://universe.roboflow.com/tez-nwkf5/tez_roi_aug

Provided by a Roboflow user
License: CC BY 4.0

